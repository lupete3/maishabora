@extends('layouts.backend')

@section('title', 'Tableau de bord Admin')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:admin.admin-dashboard />

</div>


@endsection
