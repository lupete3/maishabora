@extends('layouts.backend')

@section('title', 'Enregistrement des membres')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:members.register-member-by-recouvreur />

</div>


@endsection
