@extends('layouts.backend')

@section('title', 'Souscription')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:members.create-subscription />

</div>


@endsection
