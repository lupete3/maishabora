@extends('layouts.backend')

@section('title', 'Gestion Epargne Membres')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:admin.deposit-for-member />

</div>


@endsection
