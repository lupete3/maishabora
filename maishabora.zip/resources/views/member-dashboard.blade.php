@extends('layouts.backend')

@section('title', 'Tableau de bord memebre')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:members.member-dashboard />

</div>


@endsection
