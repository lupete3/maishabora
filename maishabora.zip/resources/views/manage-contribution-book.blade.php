@extends('layouts.backend')

@section('title', 'Depot Journalier')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:members.manage-contribution-book />

</div>


@endsection
