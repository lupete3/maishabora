@extends('layouts.backend')

@section('title', 'Transfert comptes')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:transfer-to-central-cash lazy />

</div>


@endsection
