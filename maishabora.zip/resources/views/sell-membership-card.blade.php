@extends('layouts.backend')

@section('title', 'Vendre une carte')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:members.sell-membership-card />

</div>


@endsection
