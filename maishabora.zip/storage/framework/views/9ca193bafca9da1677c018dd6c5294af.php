<!-- Modal -->
<div class="modal fade" id="modalRetraitMembre" tabindex="-1" aria-labelledby="modalRetraitMembreLabel"
    aria-hidden="true" data-focus="false" wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form wire:submit.prevent="submitRetrait">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalRetraitMembreLabel"><?php echo e(__("Effectuer un retrait")); ?></h5>
                    <button type="button" class="btn-close" aria-label="Close" wire:click='closeRetraitModal'></button>
                </div>

                <div class="modal-body row">


                    <div class="col-md-6 mb-3">
                        <label>Devise</label>
                        <select wire:model="currency" class="form-control">
                            <option value="">Choisir devise</option>
                            <option value="USD">USD</option>
                            <option value="CDF">CDF</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Montant</label>
                        <input type="number" step="0.01" wire:model="amount" class="form-control" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click='closeRetraitModal'><?php echo e(__('Fermer')); ?></button>
                    <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                        <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>
                        <?php echo e(__('Rétirer')); ?>

                    </button>
                </div>
            </form>
        </div>

    </div>
</div>


<!-- Table des adhésions (inchangée) -->
<?php /**PATH C:\laragon\www\maishabora\resources\views/livewire/admin/add-retrait-for-member.blade.php ENDPATH**/ ?>