<!-- resources/views/livewire/register-member.blade.php -->
<div class="mt-4">

    <div class="card mb-4">
        <h5 class="card-header text-lg font-medium text-gray-900">Informations du memebre</h5>

        <div class="card-body">
            <p class="text-muted mb-4">
                <?php echo e(__('Complétez toules informations du membre pour la création de son compte')); ?>

            </p>

            <form wire:submit.prevent="submit">
                <div class="row g-3">

                    <!-- Nom -->
                    <div class="col-md-4 mb-1">
                        <label for="name" class="form-label">Nom</label>
                        <input type="text" wire:model.defer="name" id="name" class="form-control" placeholder="Nom"
                            required autofocus />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Postnom -->
                    <div class="col-md-4 mb-1">
                        <label for="postnom" class="form-label">Postnom</label>
                        <input type="text" wire:model.defer="postnom" id="postnom" class="form-control"
                            placeholder="Postnom" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['postnom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Prenom -->
                    <div class="col-md-4 mb-1">
                        <label for="prenom" class="form-label">Prénom (optionnel)</label>
                        <input type="text" wire:model.defer="prenom" id="prenom" class="form-control"
                            placeholder="Prénom" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Date de naissance -->
                    <div class="col-md-4 mb-1">
                        <label for="date_naissance" class="form-label">Date de naissance</label>
                        <input type="date" wire:model.defer="date_naissance" id="date_naissance" class="form-control"
                            required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Téléphone -->
                    <div class="col-md-4 mb-1">
                        <label for="telephone" class="form-label">Téléphone</label>
                        <input type="text" wire:model.defer="telephone" id="telephone" class="form-control"
                            placeholder="+243..." required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Profession -->
                    <div class="col-md-4 mb-1">
                        <label for="profession" class="form-label">Profession</label>
                        <input type="text" wire:model.defer="profession" id="profession" class="form-control"
                            placeholder="Ex: Agriculteur" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Email -->
                    <div class="col-md-4 mb-1">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" wire:model.defer="email" id="email" class="form-control"
                            placeholder="exemple@domaine.com" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Mot de passe -->
                    <div class="col-md-4 mb-1 form-password-toggle">
                        <label class="form-label" for="password">Mot de passe</label>
                        <div class="input-group input-group-merge">
                            <input type="password" wire:model.defer="password" id="password" class="form-control"
                                placeholder="••••••••" required />
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Confirmer mot de passe -->
                    <div class="col-md-4 mb-1 form-password-toggle">
                        <label class="form-label" for="password_confirmation">Confirmer le mot de passe</label>
                        <div class="input-group input-group-merge">
                            <input type="password" wire:model.defer="password_confirmation" id="password_confirmation"
                                class="form-control" placeholder="••••••••" required />
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Adresse physique -->
                    <div class="col-md-12 mb-1">
                        <label for="adresse_physique" class="form-label">Adresse physique</label>
                        <textarea wire:model.defer="adresse_physique" id="adresse_physique" class="form-control"
                            rows="3"></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['adresse_physique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Bouton Enregistrer -->
                    <div class="col-md-12 mt-3">
                        <button type="submit" class="btn btn-primary me-3" wire:loading.attr="disabled">
                            <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>
                            Enregistrer
                        </button>

                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\imf\resources\views/livewire/members/register-member.blade.php ENDPATH**/ ?>