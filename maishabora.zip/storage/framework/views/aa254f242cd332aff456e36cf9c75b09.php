<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class=" overflow-hidden shadow-xl sm:rounded-lg p-2">

            <h2 class="text-2xl font-bold mb-4">Tableau de bord - <?php echo e($user->name); ?> <?php echo e($user->postnom); ?></h2>

            <div class="row g-4">
                <!-- Informations personnelles -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-primary text-white">Informations personnelles</div>
                        <div class="card-body pt-4">
                            <h6><strong>Nom :</strong> <?php echo e($user->name); ?> <?php echo e($user->postnom); ?></h6>
                            <h6><strong>Email :</strong> <?php echo e($user->email); ?></h6>
                            <h6><strong>Téléphone :</strong> <?php echo e($user->telephone); ?></h6>
                            <h6><strong>Date de naissance :</strong> <?php echo e($user->date_naissance); ?></h6>
                        </div>
                    </div>
                </div>

                <!-- Statistiques -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-success text-white">Statistiques</div>
                        <div class="card-body pt-4">
                            <h6><strong>Total déposé :</strong> <?php echo e(number_format($totalDeposited, 0, ',', '.')); ?> FC</h6>
                            <h6><strong>Total récupéré :</strong> <?php echo e(number_format($totalWithdrawn, 0, ',', '.')); ?> FC</h6>
                            <!--[if BLOCK]><![endif]--><?php if($totalWithdrawn > 0): ?>
                                <h6><strong>Montant soutiré :</strong> <?php echo e(number_format($totalDeposited - $totalWithdrawn, 0, ',', '.')); ?> FC</h6>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <!-- Carnets d'adhésion -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-secondary text-white">Carnets d'adhésion</div>
                        <div class="card-body pt-4">
                            <!--[if BLOCK]><![endif]--><?php if($membershipCards->isNotEmpty()): ?>
                                <ul class="list-group">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $membershipCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            Code : <?php echo e($card->code); ?> | Prix : <?php echo e(number_format($card->prix, 0, ',', '.')); ?> FC |
                                            Date : <?php echo e($card->vendu_a); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            <?php else: ?>
                                <h6>Aucun carnet d'adhésion trouvé.</h6>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <!-- Souscriptions -->
                <div class="col-md-12 mt-4">
                    <div class="card">
                        <div class="card-header bg-info text-white">Souscriptions</div>
                        <div class="card-body pt-4">
                            <!--[if BLOCK]><![endif]--><?php if($subscriptions->isNotEmpty()): ?>
                                <div class="row">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 mb-3">
                                            <div class="card">
                                                <div class="card-body pt-4">
                                                    <h5 class="card-title"><?php echo e(__('Montant souscrit')); ?> : <?php echo e(number_format($subscription->montant_souscrit, 0, ',', '.')); ?> FC</h5>
                                                    <h6><strong><?php echo e(__('Statut')); ?> :</strong> <span class="badge bg-<?php echo e($subscription->statut == 'retire' ? 'success' : 'info'); ?>"><?php echo e(ucfirst($subscription->statut)); ?></span></h6>
                                                    <h6><strong><?php echo e(__('Carnet associé')); ?> :</strong> <?php echo e(optional($subscription->contributionBooks)->code ?? 'Aucun'); ?></h6>
                                                    <h6><strong><?php echo e(__('Dépôt total')); ?> :</strong> <?php echo e(number_format(optional($subscription->contributionBooks)->lines->sum('montant'), 0, ',', '.')); ?> FC</h6>
                                                </div>
                                                <!--[if BLOCK]><![endif]--><?php if($subscription->statut == 'retire'): ?>

                                                        <a href="<?php echo e(route('member.book.pdf', ['book' => $subscription->contributionBooks->id])); ?>" class="btn btn-sm btn-primary m-2">
                                                            <i class="menu-icon tf-icons bx bx-download"></i>
                                                            <?php echo e(__('Télécharger PDF')); ?>

                                                        </a>

                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            <?php else: ?>
                                <h6>Aucune souscription trouvée.</h6>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <div class="col-md-12 mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">Suivi des dépôts</div>
        <div class="card-body">
            <!--[if BLOCK]><![endif]--><?php if(!empty($contributionLabels)): ?>
                <canvas id="contributionsChart" width="800" height="300"></canvas>

                <script>
                    window.contributionLabels = <?php echo json_encode($contributionLabels, 15, 512) ?>;
                    window.contributionData = <?php echo json_encode($contributionData, 15, 512) ?>;

                    // Si le canvas est chargé après, on peut relancer le graphique
                    document.addEventListener('livewire:navigated', () => {
                        const ctx = document.getElementById('contributionsChart');
                        if (ctx && typeof Chart !== 'undefined') {
                            new Chart(ctx, {
                                type: 'line',
                                data: {
                                    labels: window.contributionLabels,
                                    datasets: [{
                                        label: 'Montant déposé (FC)',
                                        data: window.contributionData,
                                        borderColor: 'rgba(75, 192, 192, 1)',
                                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                        fill: true,
                                        tension: 0.4
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    plugins: {
                                        legend: { display: true },
                                        tooltip: {
                                            callbacks: {
                                                label: function(context) {
                                                    return context.parsed.y + ' FC';
                                                }
                                            }
                                        }
                                    }
                                }
                            });
                        }
                    });
                </script>
            <?php else: ?>
                <p>Aucune donnée disponible pour le graphique.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\gestion-membres\resources\views/livewire/members/member-dashboard.blade.php ENDPATH**/ ?>