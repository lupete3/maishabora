<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Récapitulatif Carnet - <?php echo e($book->code); ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
            margin: 1px;
            color: #000;
        }

        .header {
            text-align: center;
            margin-bottom: 10px;
        }

        h2 {
            font-size: 14px;
            margin-bottom: 5px;
        }

        h4 {
            margin-top: 10px;
            font-size: 14px;
            border-bottom: 1px solid #999;
            padding-bottom: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 5px;
        }

        th, td {
            border: 0.5px solid #444;
            padding: 5px;
            text-align: center;
        }

        th {
            background-color: #f0f0f0;
        }

        .total {
            font-weight: bold;
            margin-top: 15px;
            font-size: 12px;
        }
    </style>
</head>
<body>

<div class="header">
    <h2><?php echo e(__('Récapitulatif du carnet')); ?> : <?php echo e($book->code); ?></h2>
    <p><strong><?php echo e(__('Membre')); ?> :</strong> <?php echo e($user->name); ?> <?php echo e($user->postnom); ?></p>
</div>

<h4><?php echo e(__('Détails des dépôts')); ?> | <strong><?php echo e(__('Date de création')); ?> :</strong> <?php echo e($book->subscription->cree_a); ?></h4>

<table>
    <thead>
        <tr>
            <th><?php echo e(__('Jour')); ?></th>
            <th><?php echo e(__('Date')); ?></th>
            <th><?php echo e(__('Montant')); ?> (FC)</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($line->montant > 0): ?>
                <tr>
                    <td><?php echo e($line->numero_ligne); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($line->date_contribution) ?? '-')); ?></td>
                    <td><?php echo e(number_format($line->montant, 0, ',', '.') ?? '-'); ?></td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<p class="total"><?php echo e(__('Total déposé')); ?> : <?php echo e(number_format($totalDeposited, 0, ',', '.')); ?> FC</p>
<p class="total"><?php echo e(__('Total rétiré')); ?> : <?php echo e(number_format($totalDeposited - $line->montant, 0, ',', '.')); ?> FC</p>

</body>
</html>
<?php /**PATH C:\laragon\www\gestion-membres\resources\views/pdf/contribution-book.blade.php ENDPATH**/ ?>