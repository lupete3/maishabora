<!-- Modal -->
<div class="modal fade" id="modalCashRegister" tabindex="-1" aria-labelledby="modalVenteCarnetLabel" aria-hidden="true"
    data-focus="false" wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form wire:submit.prevent="submit">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalVenteCarnetLabel"><?php echo e(__("Gérer la caisse centrale")); ?>

                    </h5>
                    <button type="button" class="btn-close" aria-label="Close" wire:click='closeModal'></button>
                </div>

                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6 mt-2">
                            <label for="currency"><?php echo e(__('Devise')); ?></label>
                            <select wire:model="currency" id="currency" class="form-control">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($curr); ?>"><?php echo e($curr); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="type">Type d'opération</label>
                            <select wire:model="type" id="type" class="form-control">
                                <option value="in">Entrée</option>
                                <option value="out">Sortie</option>
                            </select>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="amount">Montant</label>
                            <input type="number" step="0.01" wire:model="amount" id="amount" class="form-control" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="description">Description</label>
                            <input type="text" wire:model="description" class="form-control" />
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" wire:click='closeModal'><?php echo e(__('Fermer')); ?></button>
                    <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                        <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>
                        <?php echo e($type === 'in' ? 'Valider' : 'Retirer'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Table des adhésions (inchangée) -->
<?php /**PATH C:\laragon\www\maishabora\resources\views/livewire/admin/add-cash-register.blade.php ENDPATH**/ ?>