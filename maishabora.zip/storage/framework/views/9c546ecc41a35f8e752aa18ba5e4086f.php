<!-- Modal -->
<div class="modal fade" id="modalVenteCarnet" tabindex="-1" aria-labelledby="modalVenteCarnetLabel" aria-hidden="true"
    data-focus="false" wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form wire:submit.prevent="<?php echo e($editModal ? 'updateCard' : 'sellCard'); ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalVenteCarnetLabel"><?php echo e(__("Vendre un carnet d'adhésion")); ?>

                    </h5>
                    <button type="button" class="btn-close" aria-label="Close" wire:click='closeModal'></button>
                </div>

                <div class="modal-body">

                    <!-- Membres -->
                    <div wire:ignore>
                        <label for="user_id" class="form-label"><?php echo e(__('Choisir un membre')); ?></label>
                        <select wire:model="user_id" id="user_id" style="width: 100%"
                            class="form-control select2 <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " >

                            <option value="" disabled><?php echo e(__('-- Sélectionner --')); ?></option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> <?php echo e($user->postnom); ?>

                                    (<?php echo e($user->email); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        wire:click='closeModal'><?php echo e(__('Fermer')); ?></button>
                    <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                        <span wire:loading wire:target="sellCard" class="spinner-border spinner-border-sm me-2"
                            role="status"></span>
                        <span wire:loading wire:target="updateCard" class="spinner-border spinner-border-sm me-2"
                            role="status"></span>
                        <?php echo e($editModal ? __('Mettre à jour') : __('Vendre le carnet')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    window.addEventListener('openModal', event => {
        const modalId = '#' + event.detail.name;

        $(document).ready(function () {
            const selectElement = $(modalId).find('.select2');
            selectElement.select2({
                dropdownParent: $(modalId)
            });

            // Synchroniser avec Livewire
            selectElement.on('change', function (e) {
                const data = $(this).val();
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('user_id', data); // synchronise avec la propriété Livewire
            });
        });
    });
</script>


<!-- Table des adhésions (inchangée) -->
<?php /**PATH C:\laragon\www\imf\resources\views/livewire/members/add-sell-members.blade.php ENDPATH**/ ?>