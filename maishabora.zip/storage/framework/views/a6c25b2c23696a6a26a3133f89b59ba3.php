<?php $__env->startSection('title', 'Tableau de bord Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-xxl flex-grow-1 container-p-y">

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.admin-dashboard', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964049879-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\gestion-membres\resources\views/admin-dashboard.blade.php ENDPATH**/ ?>