<?php

use App\Livewire\Actions\Logout;
use Illuminate\Support\Facades\Auth;
use Livewire\Volt\Component;

?>

<div class="card">
    <h2 class="card-header text-lg font-medium text-gray-900">Suppression du compte</h2>

    <div class="card-body">
        <div class="mb-3 col-12 mb-0">
            <div class="alert alert-warning">
                <h6 class="alert-heading fw-bold mb-1">Êtes-vous sûr de vouloir supprimer votre compte ?</h6>
                <p class="mb-0">
                    Une fois votre compte supprimé, toutes ses données seront définitivement perdues. Veuillez saisir votre mot de passe pour confirmer.
                </p>
            </div>
        </div>

        <!-- Formulaire Livewire -->
        <form wire:submit.prevent="deleteUser">
            <!-- Mot de passe -->
            <div class="mb-3">
                <label for="password" class="form-label">Mot de passe</label>
                <input
                    wire:model.defer="password"
                    type="password"
                    id="password"
                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="Mot de passe"
                    required
                />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Confirmation -->
            <div class="form-check mb-3">
                <input
                    wire:model="confirmation"
                    class="form-check-input"
                    type="checkbox"
                    id="confirmationSuppression"
                />
                <label class="form-check-label" for="confirmationSuppression">
                    Je confirme la suppression de mon compte
                </label>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Boutons -->
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-danger" wire:loading.attr="disabled">
                    <span wire:loading wire:target="deleteUser" class="spinner-border spinner-border-sm me-2" role="status"></span>
                    Supprimer mon compte
                </button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\maishabora\resources\views\livewire/profile/delete-user-form.blade.php ENDPATH**/ ?>