<!-- resources/views/livewire/register-member.blade.php -->
<div class="mt-4">

    <?php echo $__env->make('livewire.members.add-member', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- resources/views/livewire/view-registered-members.blade.php -->
    <div class="table-wrapper">
        <div class="card has-actions has-filter">

            <div class="card-header">
                <div class="w-100 justify-content-between d-flex flex-wrap align-items-center gap-1">

                    <div class="d-flex flex-wrap flex-md-nowrap align-items-center gap-1">
                        <button class="btn btn-show-table-options" type="button">Rechercher</button>

                        <div class="table-search-input">
                            <label>
                                <input type="search" wire:model.live="search" class="form-control input-sm"
                                    placeholder="Rechercher..." style="min-width: 120px">
                            </label>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2">
                        <select wire:model.live="perPage" class="form-select form-select-sm">
                            <option value="10">10</option>
                            <option value="30">30</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                            <option value="999999">Tous</option>
                        </select>
                        <button class="btn btn-sm action-item btn-primary" wire:click='openModal'>
                            <?php echo e(__("Ajouter")); ?>

                        </button>
                    </div>
                </div>
            </div>

            <div class="card-table">
                <div class="table-responsive table-has-actions table-has-filter">
                    <table
                        class="table card-table table-vcenter table-striped table-hover dataTable no-footer dtr-inline collapsed">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Solde USD</th>
                                <th>Solde CDF</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($member->code); ?></td>
                                    <td><?php echo e($member->name); ?></td>
                                    <td><?php echo e($member->email); ?></td>
                                    <td><?php echo e($member->telephone ?? '-'); ?></td>
                                    <td>
                                        <?php echo e(number_format($member->accounts->firstWhere('currency', 'USD')?->balance ?? 0, 2)); ?>

                                    </td>
                                    <td>
                                        <?php echo e(number_format($member->accounts->firstWhere('currency', 'CDF')?->balance ?? 0, 2)); ?>

                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-1">
                                            <a href="<?php echo e(route('member.details', $member->id)); ?>" wire:navigate class="btn btn-sm btn-primary">Compte Client</a>
                                            <button wire:click='edit(<?php echo e($member->id); ?>)'
                                                class="btn btn-sm btn-info"><?php echo e(__('Modifier')); ?></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">
                                        <div class="alert alert-danger" role="alert">
                                            Aucun membre trouvé.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
                <div class="d-flex justify-content-between align-items-center gap-3">
                    <div>
                        <label>
                            <select wire:model.lazy="perPage" class="form-select form-select-sm">
                                <option value="10">10</option>
                                <option value="30">30</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="999999">Tous</option>
                            </select>
                        </label>
                    </div>
                    <div class="text-muted">
                        Affichage de <?php echo e($members->firstItem()); ?> à <?php echo e($members->lastItem()); ?> sur
                        <span class="badge bg-primary"><?php echo e($members->total()); ?></span> membres
                    </div>
                </div>

                <div class="d-flex justify-content-center">
                    <?php echo e($members->links()); ?>

                </div>
            </div>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\maishabora\resources\views/livewire/members/register-member.blade.php ENDPATH**/ ?>