<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;
use Livewire\Volt\Component;

?>

<div class="card mb-4">
    <h5 class="card-header text-lg font-medium text-gray-900">Modifier le mot de passe</h5>

    <div class="card-body">
        <p class="text-muted mb-3">
            Assurez-vous d’utiliser un mot de passe long et complexe pour sécuriser votre compte.
        </p>

        <form wire:submit.prevent="updatePassword">
            <!-- Mot de passe actuel -->
            <div class="mb-3">
                <label for="current_password" class="form-label">Mot de passe actuel</label>
                <input
                    wire:model.defer="current_password"
                    type="password"
                    class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="current_password"
                    autocomplete="current-password"
                >
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Nouveau mot de passe -->
            <div class="mb-3">
                <label for="password" class="form-label">Nouveau mot de passe</label>
                <input
                    wire:model.defer="password"
                    type="password"
                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="password"
                    autocomplete="new-password"
                >
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Confirmation -->
            <div class="mb-3">
                <label for="password_confirmation" class="form-label">Confirmer le mot de passe</label>
                <input
                    wire:model.defer="password_confirmation"
                    type="password"
                    class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="password_confirmation"
                    autocomplete="new-password"
                >
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Bouton -->
            <div class="d-flex align-items-center">
                <button type="submit" class="btn btn-primary me-3" wire:loading.attr="disabled">
                    <span wire:loading wire:target="updatePassword" class="spinner-border spinner-border-sm me-2" role="status"></span>
                    Enregistrer
                </button>

                <span class="text-success" wire:loading.remove wire:target="updatePassword" wire:transition>
                    <!--[if BLOCK]><![endif]--><?php if(session()->has('status') && session('status') === 'password-updated'): ?>
                        Mot de passe mis à jour avec succès.
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </span>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\gestion-membres\resources\views\livewire/profile/update-password-form.blade.php ENDPATH**/ ?>