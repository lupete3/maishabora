<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="<?php echo e(route('dashboard')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo ">
                <img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" width="50px" alt="" class="mr-2">
            </span>
            <?php echo e(config( 'app.name', 'Laravel')); ?>


        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        <li class="menu-item <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Tableau de bord</div>
            </a>
        </li>

        <!-- Liens Compable-->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isCaissier', App\Models\User::class)): ?>
            <li class="menu-item <?php if(request()->routeIs('cash.register')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('cash.register')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-wallet"></i>
                    <div data-i18n="Analytics">Caisse Centrale</div>
                </a>
            </li>

            
            <li class="menu-item <?php if(request()->routeIs('agent.dashboard')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('agent.dashboard')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-wallet"></i>
                    <div data-i18n="Analytics">Caisse Agents</div>
                </a>
            </li>




        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isRecouvreur', App\Models\User::class)): ?>
            <li class="menu-item <?php if(request()->routeIs('member.register','member.details','receipt.generate')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('member.register')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-user"></i>
                    <div data-i18n="Analytics">Gestion des membres</div>
                </a>
            </li>
            
        <?php endif; ?>





        



        
        

        


    </ul>
</aside>
<?php /**PATH C:\laragon\www\maishabora\resources\views/layouts/partials/aside.blade.php ENDPATH**/ ?>