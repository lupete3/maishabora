<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <?php echo e(date('Y')); ?>

            , made with ❤️ by
            <a href="https://pdevtuto.com" target="_blank" class="footer-link fw-bolder">Pdevtuto</a>
        </div>
        <div>
            <a href="https://pdevtuto.com" class="footer-link me-4" target="_blank">License</a>
            <a href="https://pdevtuto.com" target="_blank" class="footer-link me-4">More Themes</a>

            <a href="https://pdevtuto.com" target="_blank"
                class="footer-link me-4">Documentation</a>

            <a href="https://pdevtuto" target="_blank"
                class="footer-link me-4">Support</a>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\imf\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>