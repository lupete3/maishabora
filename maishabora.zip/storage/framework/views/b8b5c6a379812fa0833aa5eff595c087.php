<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-2">

            <h2 class="text-2xl font-bold mb-4">Historique financier</h2>
            <a href="<?php echo e(route('member.history.excel')); ?>" class="btn btn-success mb-3">
                <i class="bi bi-file-earmark-excel"></i> Exporter en Excel
            </a>

            <!--[if BLOCK]><![endif]--><?php if($operations): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="">
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Description</th>
                            <th>Entrée (FC)</th>
                            <th>Sortie (FC)</th>
                            <th>Référence</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $solde = 0;
                        ?>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                if ($operation->type_operation === 'Adhésion' || $operation->type_operation === 'Contribution')
                                {
                                    $entree = $operation->montant;
                                    $sortie = 0;
                                    $solde += $entree;
                                } else {
                                    $entree = 0;
                                    $sortie = $operation->montant;
                                    $solde -= $sortie;
                                }
                            ?>
                            <tr>
                                <td><?php echo e($operation->created_at->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($operation->type_operation); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($operation->reference_type === 'App\Models\MembershipCard'): ?>
                                    Achat du carnet <?php echo e(optional($operation->reference)->code ?? '-'); ?>

                                    <?php elseif($operation->reference_type === 'App\Models\ContributionLine'): ?>
                                    Dépôt quotidien - Carnet <?php echo e(optional(optional($operation->reference)->contributionBook)->code ?? '-'); ?>

                                    <?php elseif($operation->reference_type === 'App\Models\ContributionBook'): ?>
                                    Retrait du carnet <?php echo e(optional($operation->reference)->code ?? '-'); ?>

                                    <?php else: ?>
                                    Opération inconnue
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td class="text-success"><?php echo e(number_format($entree, 0, ',', '.')); ?></td>
                                <td class="text-danger"><?php echo e(number_format($sortie, 0, ',', '.')); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($operation->reference_type === 'App\Models\MembershipCard'): ?>
                                    <?php echo e(optional($operation->reference)->code ?? '-'); ?>

                                    <?php elseif($operation->reference_type === 'App\Models\ContributionLine'): ?>
                                    <?php echo e(optional(optional($operation->reference)->book)->code ?? '-'); ?> - Ligne <?php echo e(optional($operation->reference)->numero_ligne ?? '-'); ?>

                                    <?php elseif($operation->reference_type === 'App\Models\ContributionBook'): ?>
                                    <?php echo e(optional($operation->reference)->code ?? '-'); ?>

                                    <?php else: ?>
                                    -
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center"><div class="alert alert-danger" role="alert"><?php echo e(__('Aucune information disponible pour le moment')); ?></div></td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>

                </table>
            </div>
            <?php else: ?>
            <div class="alert alert-info">Aucune opération trouvée.</div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>
        <div class="card-footer d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">

            <div class="d-flex justify-content-between align-items-center gap-3">

                <!-- Informations sur la pagination -->
                <div class="text-muted">
                    <svg class="icon svg-icon-ti-ti-world" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"></path>
                        <path d="M3.6 9h16.8"></path>
                        <path d="M3.6 15h16.8"></path>
                        <path d="M11.5 3a17 17 0 0 0 0 18"></path>
                        <path d="M12.5 3a17 17 0 0 1 0 18"></path>
                    </svg>
                    <span class="d-none d-sm-inline">Affichage de</span>
                    <?php echo e($operations->firstItem()); ?> à <?php echo e($operations->lastItem()); ?> sur
                    <span class="badge bg-secondary text-secondary-fg">
                        <?php echo e($operations->total()); ?>

                    </span>
                    <span class="hidden-xs">enregistrements</span>
                </div>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?php echo e($operations->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\gestion-membres\resources\views/livewire/members/member-financial-history.blade.php ENDPATH**/ ?>