<div>
    <div class="card mb-4">
        <h5 class="card-header text-lg font-medium text-gray-900">Enregistrer un nouveau membre</h5>

        <div class="card-body">
            <p class="text-muted mb-4">
                Compléter toutes les zones de texte recquises avant d'enregistrer.
            </p>

            <form wire:submit.prevent="register" class="row g-3">

                <!-- Nom -->
                <div class="col-md-4">
                    <label for="name" class="form-label">Nom</label>
                    <input wire:model.defer="name" id="name" type="text" class="form-control">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Postnom -->
                <div class="col-md-4">
                    <label for="postnom" class="form-label">Postnom</label>
                    <input wire:model.defer="postnom" id="postnom" type="text" class="form-control">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['postnom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Prénom -->
                <div class="col-md-4">
                    <label for="prenom" class="form-label">Prénom (optionnel)</label>
                    <input wire:model.defer="prenom" id="prenom" type="text" class="form-control">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Date de naissance -->
                <div class="col-md-4">
                    <label for="date_naissance" class="form-label">Date de naissance</label>
                    <input wire:model.defer="date_naissance" id="date_naissance" type="date" class="form-control">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Téléphone -->
                <div class="col-md-4">
                    <label for="telephone" class="form-label">Téléphone</label>
                    <input wire:model.defer="telephone" id="telephone" type="text" class="form-control"
                        placeholder="+243999999999">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Email -->
                <div class="col-md-4">
                    <label for="email" class="form-label">Email</label>
                    <input wire:model.defer="email" id="email" type="email" class="form-control">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Adresse physique -->
                <div class="col-md-6">
                    <label for="adresse_physique" class="form-label">Adresse physique</label>
                    <textarea wire:model.defer="adresse_physique" id="adresse_physique" rows="2"
                        class="form-control"></textarea>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['adresse_physique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Profession -->
                <div class="col-md-6">
                    <label for="profession" class="form-label">Profession</label>
                    <input wire:model.defer="profession" id="profession" type="text" class="form-control">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Bouton soumission -->
                <div class="col-md-12 mt-3">
                    <button type="submit" class="btn btn-primary">
                        <span wire:loading wire:target="register" class="spinner-border spinner-border-sm me-2"
                            role="status"></span>
                        Enregistrer le membre
                    </button>
                </div>

            </form>

        </div>
    </div>



    <div class="page-wrapper">
        <div class="page-header d-print-none">
            <div class="">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <div class="page-pretitle">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a class="mb-0 d-inline-block fs-6 lh-1" href="<?php echo e(route('dashboard')); ?>"><?php echo e(__("Tableau de bord")); ?></a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <h1 class="mb-0 d-inline-block fs-6 lh-1"><?php echo e(__("Historique d'adhésions des
                                            membres")); ?></h1>
                                    </li>
                                </ol>
                            </nav>

                        </div>
                    </div>
                    <div class="col-auto ms-auto d-print-none">
                        <div class="btn-list">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="page-body page-content">
            <div class="">

                <div class="table-wrapper">

                    <div class="card has-actions has-filter">
                        <div class="card-header">
                            <div class="w-100 justify-content-between d-flex flex-wrap align-items-center gap-1">

                                <div class="d-flex flex-wrap flex-md-nowrap align-items-center gap-1">
                                    <button class="btn btn-show-table-options" type="button">Rechercher</button>

                                    <div class="table-search-input">
                                        <label>
                                            <input type="search" wire:model.live="search" class="form-control input-sm"
                                                placeholder="Rechercher..." style="min-width: 120px">
                                        </label>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center gap-1">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
                                        + <?php echo e(__('Nouvel utilisateur')); ?>

                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="card-table">
                            <div class="table-responsive table-has-actions table-has-filter">
                                <table
                                    class="table card-table table-vcenter table-striped table-hover dataTable no-footer dtr-inline collapsed">
                                    <thead>
                                        <tr>
                                            <th>Nom</th>
                                            <th>Postnom</th>
                                            <th>Email</th>
                                            <th>Rôle</th>
                                            <th>Date création</th>
                                            <th>Statut</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="odd">
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->postnom); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php switch($user->role):
                                                case ('admin'): ?>
                                                <span class="badge bg-label-danger me-1"><?php echo e(ucfirst($user->role)); ?></span>
                                                <?php break; ?>

                                                <?php case ('caissier'): ?>
                                                <span class="badge bg-label-warning me-1"><?php echo e(ucfirst($user->role)); ?></span>
                                                <?php break; ?>

                                                <?php case ('recouvreur'): ?>
                                                <span class="badge bg-label-info me-1"><?php echo e(ucfirst($user->role)); ?></span>
                                                <?php break; ?>

                                                <?php default: ?>
                                                <span class="badge bg-label-success me-1"><?php echo e(ucfirst($user->role)); ?></span>
                                                <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($user->status): ?>
                                                <span class="badge bg-label-success me-1">Actif</span>
                                                <?php else: ?>
                                                <span class="badge bg-label-secondary me-1">Inactif</span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                        data-bs-toggle="dropdown">
                                                        <i class="bx bx-dots-vertical-rounded"></i>
                                                    </button>
                                                    <div class="dropdown-menu">

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isRecouvreur', App\Models\User::class)): ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($user->role === 'membre'): ?>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('member.dashboard', ['id' => $user->id])); ?>">
                                                            <i class="bx bx-user me-1"></i> Voir profil
                                                        </a>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin',App\Models\User::class)): ?>
                                                        <a class="dropdown-item" wire:click="editUser(<?php echo e($user->id); ?>)"
                                                            href="javascript:void(0);">
                                                            <i class="bx bx-edit-alt me-1"></i> Modifier
                                                        </a>
                                                        <a class="dropdown-item"
                                                            wire:click="deleteUser(<?php echo e($user->id); ?>)"
                                                            href="javascript:void(0);">
                                                            <i class="bx bx-trash me-1"></i> Supprimer
                                                        </a>
                                                        <a class="dropdown-item"
                                                            wire:click="changeRole(<?php echo e($user->id); ?>)"
                                                            href="javascript:void(0);">
                                                            <i class="bx bx-shield-quarter me-1"></i> Changer de rôle
                                                        </a>
                                                        <?php endif; ?>

                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin|isCaissier', App\Models\User::class)): ?>
                                                        <a class="dropdown-item"
                                                            wire:click="toggleStatus(<?php echo e($user->id); ?>)"
                                                            href="javascript:void(0);">
                                                            <i class="bx bx-block me-1"></i> <?php echo e($user->status ?
                                                            'Désactiver' : 'Activer'); ?>

                                                        </a>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center">
                                                <div class="alert alert-danger" role="alert">
                                                    Aucune information disponible pour le moment
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div
                            class="card-footer d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
                            <div class="d-flex justify-content-between align-items-center gap-3">
                                <div>
                                    <label>
                                        <select wire:model.lazy="perPage" class="form-select form-select-sm">
                                            <option value="10">10</option>
                                            <option value="30">30</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                            <option value="999999">Tous</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="text-muted">
                                    Affichage de <?php echo e($users->firstItem()); ?> à <?php echo e($users->lastItem()); ?> sur
                                    <span class="badge bg-secondary"><?php echo e($users->total()); ?></span> enregistrements
                                </div>
                            </div>

                            <div class="d-flex justify-content-center">
                                <?php echo e($users->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>
<?php /**PATH C:\laragon\www\gestion-membres\resources\views/livewire/members/register-member-by-recouvreur.blade.php ENDPATH**/ ?>