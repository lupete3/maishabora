<!-- resources/views/livewire/manage-cash-register.blade.php -->
<div>
    <div class="page-header d-print-none">
        <div class="">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <div class="page-pretitle">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a class="mb-0 d-inline-block fs-6 lh-1" href="<?php echo e(route('dashboard')); ?>"><?php echo e(__("Tableau de bord")); ?></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <h1 class="mb-0 d-inline-block fs-6 lh-1"><?php echo e(__("Situation de la caisse centrale")); ?></h1>
                                </li>
                            </ol>
                        </nav>

                    </div>
                </div>
                <div class="col-auto ms-auto d-print-none">
                    <div class="btn-list">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="row">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $registers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--[if BLOCK]><![endif]--><?php if($index == 0): ?>
                <div class="col-lg-6 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/chart-success.png" alt="chart success"
                                        class="rounded" />
                                </div>

                            </div>
                            <span>Compte USD</span>
                            <h3 class="card-title mb-2"><?php echo e($reg->currency); ?> : <?php echo e(number_format($reg->balance, 2)); ?>

                            </h3>
                            <small class="text-success fw-semibold"><i class="bx bx-up-arrow-alt"></i>
                                +72.80%</small>
                        </div>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if($index == 1): ?>
                <div class="col-lg-6 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex align-items-start justify-content-between">
                                <div class="avatar flex-shrink-0">
                                    <img src="../assets/img/icons/unicons/wallet-info.png" alt="Credit Card"
                                        class="rounded" />
                                </div>

                            </div>
                            <span>Compte CDF</span>
                            <h3 class="card-title text-nowrap mb-1"><?php echo e($reg->currency); ?> : <?php echo e(number_format($reg->balance, 2)); ?></h3>
                            <small class="text-success fw-semibold"><i class="bx bx-up-arrow-alt"></i>
                                +28.42%</small>
                        </div>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

    </div>


    <div class="table-wrapper">
        <div class="card has-actions has-filter">

            <div class="card-header">
                <div class="w-100 justify-content-between d-flex flex-wrap align-items-center gap-1">

                    <div class="d-flex flex-wrap flex-md-nowrap align-items-center gap-1">
                        <button class="btn btn-show-table-options" type="button">Rechercher</button>

                        <div class="table-search-input">
                            <label>
                                <input type="search" wire:model.live="search" class="form-control input-sm"
                                    placeholder="Rechercher..." style="min-width: 120px">
                            </label>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-1">
                        <button wire:click="openModal" class="btn btn-primary">
                            + Ajouter
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-table">
                <div class="table-responsive table-has-actions table-has-filter">
                    <table
                        class="table card-table table-vcenter table-striped table-hover dataTable no-footer dtr-inline collapsed">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Devise</th>
                                <th>Montant</th>
                                <th>Solde après</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($transaction->created_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($transaction->type === 'Entrée de fonds'): ?>
                                        <span class="badge bg-label-success me-1"><?php echo e(ucfirst($transaction->type)); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-label-danger me-1"><?php echo e(ucfirst($transaction->type)); ?></span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td><?php echo e($transaction->currency); ?></td>
                                <td><?php echo e(number_format($transaction->amount, 2)); ?></td>
                                <td><?php echo e(number_format($transaction->balance_after, 2)); ?></td>
                                <td><?php echo e($transaction->description); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">
                                    <div class="alert alert-danger" role="alert">
                                        Aucune opération trouvée.
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
                <div class="d-flex justify-content-between align-items-center gap-3">
                    <div>
                        <label>
                            <select wire:model.lazy="perPage" class="form-select form-select-sm">
                                <option value="10">10</option>
                                <option value="30">30</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="999999">Tous</option>
                            </select>
                        </label>
                    </div>
                    <div class="text-muted">
                        Affichage de <?php echo e($transactions->firstItem()); ?> à <?php echo e($transactions->lastItem()); ?> sur
                        <span class="badge bg-secondary"><?php echo e($transactions->total()); ?></span> opérations
                    </div>
                </div>

                <div class="d-flex justify-content-center">
                    <?php echo e($transactions->links()); ?>

                </div>
            </div>

        </div>
    </div>

    <?php echo $__env->make('livewire.admin.add-cash-register', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php /**PATH C:\laragon\www\imf\resources\views/livewire/admin/manage-cash-register.blade.php ENDPATH**/ ?>